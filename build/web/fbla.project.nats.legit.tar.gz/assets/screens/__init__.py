"""Pygame presentation layer."""
